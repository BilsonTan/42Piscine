#include <stdlib.h>
int	main()
{
	int	*arr;
	int	i;

	i = 0;
	arr = (int*) malloc(sizeof(int)*10);
	while( i != 10)
	{
		arr[i] = i;
		i++;
	}
}
