groups $FT_USER | tr ' ' ','

