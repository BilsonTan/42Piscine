find -iname "*.sh" -exec basename {} .sh ';'
