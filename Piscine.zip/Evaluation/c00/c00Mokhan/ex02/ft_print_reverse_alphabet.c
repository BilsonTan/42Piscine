/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mokhan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/22 14:51:51 by mokhan            #+#    #+#             */
/*   Updated: 2023/06/22 14:51:56 by mokhan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_reverse_alphabet(void)
{
	char	prevalpha;

	prevalpha = 'z';
	while (prevalpha >= 'a')
	{
		write(1, &prevalpha, 1);
		prevalpha--;
	}
}
