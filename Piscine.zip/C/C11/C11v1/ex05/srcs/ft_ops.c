/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ops.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/13 17:15:48 by bitan             #+#    #+#             */
/*   Updated: 2023/07/13 17:15:54 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	op_add(int val1, int val2)
{
	ft_putnbr(val1 + val2);
	ft_putchar('\n');
}

void	op_sub(int val1, int val2)
{
	ft_putnbr(val1 - val2);
	ft_putchar('\n');
}

void	op_mul(int val1, int val2)
{
	ft_putnbr(val1 * val2);
	ft_putchar('\n');
}

void	op_div(int val1, int val2)
{
	if (val2 == 0)
		ft_putstr("Stop : division by zero");
	else
		ft_putnbr(val1 / val2);
	ft_putchar('\n');
}

void	op_mod(int val1, int val2)
{
	if (val2 == 0)
		ft_putstr("Stop : modulo by zero");
	else
		ft_putnbr(val1 % val2);
	ft_putchar('\n');
}
