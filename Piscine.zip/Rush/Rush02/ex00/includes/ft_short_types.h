/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_short_types.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sichan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/08 14:25:12 by sichan            #+#    #+#             */
/*   Updated: 2023/07/08 14:25:16 by sichan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_SHORT_TYPES_H
# define FT_SHORT_TYPES_H

# define UINT unsigned int
# define ULNG unsigned long

#endif
