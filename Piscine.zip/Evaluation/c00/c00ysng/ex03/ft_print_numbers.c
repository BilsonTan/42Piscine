/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ysng <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/22 22:07:49 by ysng              #+#    #+#             */
/*   Updated: 2023/06/23 11:07:32 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	ft_print_numbers(void);

void	ft_print_numbers(void)
{
	char	digit;
	int		i;
	digit = '0';
	i = 0;
	while (digit <= '9')
	{
		digit = '0' + i;
		write (1, &digit, 1);
		i++;
	}
}
/*
int	main(){
ft_print_numbers();
return 0;
}*/
