/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_array_extend.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aasharma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/08 13:06:21 by aasharma          #+#    #+#             */
/*   Updated: 2023/07/08 15:26:20 by aasharma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ft_short_types.h>
#include <stdlib.h>
#include "ft_str.h"

char	*ft_extend_array(char *orig, char *n_cont, UINT old_len, UINT len)
{
	char	*dest;

	dest = malloc((len + 1) * sizeof(char));
	if (!dest)
		return (NULL);
	if (orig != NULL)
		ft_str_n_copy(dest, orig, old_len);
	ft_str_n_copy(dest + old_len, n_cont, (UINT)(len - old_len));
	return (dest);
}
