/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_linecheck.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 18:40:47 by bitan             #+#    #+#             */
/*   Updated: 2023/07/02 18:40:55 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	top_down(int board[4][4], int x)
{
	int	res;

	res = 1;
	if (board[0][x] < board[1][x])
		res++;
	if (board[0][x] < board[2][x] && board[1][x] < board[2][x])
		res++;
	if (board[0][x] < board[3][x] &&
		board[1][x] < board[3][x] &&
		board[2][x] < board[3][x])
		res++;
	return (res);
}

int	bottom_up(int board[4][4], int x)
{
	int	res;

	res = 1;
	if (board[3][x] < board[2][x])
		res++;
	if (board[3][x] < board[1][x] && board[2][x] < board[1][x])
		res++;
	if (board[3][x] < board[0][x] &&
		board[2][x] < board[0][x] &&
		board[1][x] < board[0][x])
		res++;
	return (res);
}

int	left_right(int board[4][4], int y)
{
	int	res;

	res = 1;
	if (board[y][0] < board[y][1])
		res++;
	if (board[y][0] < board[y][2] && board[y][1] < board[y][2])
		res++;
	if (board[y][0] < board[y][3] &&
		board[y][1] < board[y][3] &&
		board[y][2] < board[y][3])
		res++;
	return (res);
}

int	right_left(int board[4][4], int y)
{
	int	res;

	res = 1;
	if (board[y][3] < board[y][2])
		res++;
	if (board[y][3] < board[y][1] && board[y][2] < board[y][1])
		res++;
	if (board[y][3] < board[y][0] &&
		board[y][2] < board[y][0] &&
		board[y][1] < board[y][0])
		res++;
	return (res);
}
