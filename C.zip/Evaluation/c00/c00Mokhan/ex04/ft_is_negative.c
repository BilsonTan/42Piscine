/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mokhan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/22 15:30:48 by mokhan            #+#    #+#             */
/*   Updated: 2023/06/22 15:30:54 by mokhan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_is_negative(int n)
{
	char	negative;

	if (n < 0)
	{
		negative = 'N';
		write(1, &negative, 1);
	}
	else
	{
		negative = 'P';
		write(1, &negative, 1);
	}
}
