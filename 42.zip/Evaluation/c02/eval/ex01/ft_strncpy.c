/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tlim <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/28 16:09:03 by tlim              #+#    #+#             */
/*   Updated: 2023/06/28 17:42:36 by tlim             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n && i != '\0')
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

/*void main()
{
	int i;
	char a[1];

	*ft_strncopy(a, "asdasdqweqweqwe", 10);
}*/
