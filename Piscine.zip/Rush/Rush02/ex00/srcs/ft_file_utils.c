/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_file_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aasharma <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/08 13:26:34 by aasharma          #+#    #+#             */
/*   Updated: 2023/07/08 13:26:47 by aasharma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>

int	ft_open_file(char *path)
{
	return (open(path, O_RDONLY));
}

int	ft_close_file(int fd)
{
	return (close(fd));
}
