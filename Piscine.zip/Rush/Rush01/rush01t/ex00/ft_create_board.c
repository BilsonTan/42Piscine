/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_generate_board.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 18:40:31 by bitan             #+#    #+#             */
/*   Updated: 2023/07/02 18:40:34 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_verification(int board[4][4], int tab[16]);
void	ft_print_board(int board[4][4]);

void	ft_possible_values(int board[4][4], int x, int y, int *values)
{
	int	i;

	i = 1;
	while (i <= 4)
	{
		values[i] = 1;
		i++;
	}
	i = 0;
	while (i < 4)
	{
		if (board[i][x] != 0)
			values[board[i][x]] = 0;
		if (board[y][i] != 0)
			values[board[y][i]] = 0;
		i++;
	}
}

int	ft_check_and_print(int board[4][4], int input[16])
{
	if (ft_verification(board, input) == 1)
	{
		ft_print_board(board);
		return (1);
	}
	return (0);
}

int	ft_next_x(int x)
{
	if (x < 3)
		return (x + 1);
	else
		return (0);
}

int	ft_next_y(int x, int y)
{
	if (x < 3)
		return (y);
	else
		return (y + 1);
}

int	ft_create_board(int board[4][4], int x, int y, int input[16])
{
	int	values[5];
	int	i;
	int	next_x;
	int	next_y;

	if (x == 0 && y == 4)
		return (ft_check_and_print(board, input));
	next_x = ft_next_x(x);
	next_y = ft_next_y(x, y);
	ft_possible_values(board, x, y, values);
	i = 1;
	while (i <= 4)
	{
		if (values[i])
		{
			board[y][x] = i;
			if (ft_create_board(board, next_x, next_y, input) == 1)
				return (1);
		}
		i++;
	}
	board[y][x] = 0;
	return (0);
}
