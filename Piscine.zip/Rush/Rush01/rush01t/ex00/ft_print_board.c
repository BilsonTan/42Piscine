/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_board.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 18:41:45 by bitan             #+#    #+#             */
/*   Updated: 2023/07/02 18:41:53 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_wrtchar(char ch)
{
	write(1, &ch, 1);
}

void	ft_print_board(int board[4][4])
{
	int	i;
	int	j;

	i = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			if (j > 0)
				ft_wrtchar(' ');
			ft_wrtchar(board[i][j] + '0');
			j++;
		}
		ft_wrtchar('\n');
		i++;
	}
}
