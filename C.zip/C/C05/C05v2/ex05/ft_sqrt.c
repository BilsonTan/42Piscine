/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/06 21:03:17 by bitan             #+#    #+#             */
/*   Updated: 2023/07/06 21:13:42 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	long	val;
	long	number;

	number = (long)nb;
	val = 0;
	if (nb <= 0)
		return (0);
	while (val * val <= number)
	{
		if (val * val == number)
			return (val);
		val++;
	}
	return (0);
}
