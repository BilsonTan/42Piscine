/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/13 17:12:01 by bitan             #+#    #+#             */
/*   Updated: 2023/07/13 17:12:09 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

# include <unistd.h>

int		ft_strcmp(char *s1, char *s2);
void	ft_putstr(char *str);
int		ft_atoi(char *str);
void	ft_putnbr(int nbr);
void	ft_putlnbr(long lnbr);
void	ft_putchar(char c);
void	op_add(int val1, int val2);
void	op_sub(int val1, int val2);
void	op_mul(int val1, int val2);
void	op_div(int val1, int val2);
void	op_mod(int val1, int val2);

#endif
