/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 13:39:07 by bitan             #+#    #+#             */
/*   Updated: 2023/06/25 18:01:55 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_putchar(char c);

void	ft_conditions(int x, int y, int hx)
{
	int	vy;

	vy = 1;
	if (x < 1 || y < 1)
		return ;
	while (vy <= y)
	{
		while (hx <= x)
		{
			if ((hx == 1 && vy == 1) || (hx == x && vy == y && y > 1 && x > 1))
				ft_putchar('A');
			else if ((hx == 1 || hx == x) && (vy > 1 && vy < y))
				ft_putchar('B');
			else if ((vy == 1 || vy == y) && (hx > 1 && hx < x))
				ft_putchar('B');
			else if ((hx == x && vy == 1) || (vy == y && hx == 1))
				ft_putchar('C');
			else
				ft_putchar(' ');
			hx++;
		}
		vy++;
		hx = 1;
		ft_putchar('\n');
	}
}

void	rush(int x, int y)
{
	int	hx;

	hx = 1;
	ft_conditions(x, y, hx);
}
