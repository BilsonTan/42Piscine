/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tlim <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/28 20:07:11 by tlim              #+#    #+#             */
/*   Updated: 2023/06/29 14:07:23 by tlim             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	if (str[i] == '\0')
		return (1);
	else
	{	
		while (str[i] != '\0')
		{
			if (str[i] < 'A' || str[i] > 'z')
			{
				if (str[i] > 'Z' && str[i] < 'a')
				{
					return (0);
				}
				return (0);
			}
			i++;
		}
		return (1);
	}
}

/*void main()
{

//if (str[i] < 'A' || str[i] > 'Z' && str[i] < 'a' || str[i] > 'z')
//{
//	return (0);
//}

	if(ft_str_is_alpha("abcdefghijkl") == 1)
		printf("11111");
	else
		printf("00000");
}*/
