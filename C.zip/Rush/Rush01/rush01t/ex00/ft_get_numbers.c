/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_numbers.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 18:41:25 by bitan             #+#    #+#             */
/*   Updated: 2023/07/02 18:41:28 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlength(char *str)
{
	int	count;

	count = 0;
	while (str[count] != '\0')
		count++;
	if (count != 31)
		return (0);
	return (count);
}

int	ft_get_numbers(char *str, int *tab)
{
	int	i;

	i = 0;
	if (ft_strlength(str) != 31)
		return (0);
	while (str[i] != '\0')
	{
		if (i % 2 == 1)
		{
			if (str[i] != ' ')
				return (0);
		}
		else
		{
			if (str[i] >= '1' && str[i] <= '4')
				tab[i / 2] = (str[i] - '0');
			else
				return (0);
		}
		i++;
	}
	return (1);
}
