git log --format=format:%H  -n 5
