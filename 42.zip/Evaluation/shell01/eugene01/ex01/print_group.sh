id -Gn | tr " " ","

