/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jingtan <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/25 12:16:09 by jingtan           #+#    #+#             */
/*   Updated: 2023/06/25 16:57:52 by jingtan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	rush(int x, int y)
{	
	int	i;

	i = 1; 
	while (i < x * y + y)
	{	
		if (i == 1 || i == x * y + y - x)
			ft_putchar('A');
		else if (i == x || i == x * y + y - 1)
			ft_putchar('C');
		else if (i % (x + 1) == 0)
			ft_putchar('\n');
		else if (i > x + 1 && i < x * y + y - x)
		{
				if ((i - (x + 2)) % (x + 1) != 0 && (i - x) % (x + 1) != 0)
					ft_putchar(' ');
				else
					ft_putchar('B');
		}
		else
			ft_putchar('B');
		i++;
			
	}
	ft_putchar('\n');
}
