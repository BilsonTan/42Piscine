/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_verify.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bitan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 18:41:06 by bitan             #+#    #+#             */
/*   Updated: 2023/07/02 18:41:07 by bitan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	top_down(int board[4][4], int x);
int	bottom_up(int board[4][4], int x);
int	left_right(int board[4][4], int y);
int	right_left(int board[4][4], int y);

int	ft_verify_vertical(int board[4][4], int tab[16])
{
	int	i;

	i = 0;
	while (i < 4)
	{
		if (top_down(board, i) != tab[i])
			return (0);
		i++;
	}
	while (i < 8)
	{
		if (bottom_up(board, i - 4) != tab[i])
			return (0);
		i++;
	}
	return (1);
}

int	ft_verify_horizontal(int board[4][4], int tab[16])
{
	int	i;

	i = 8;
	while (i < 12)
	{
		if (left_right(board, i - 8) != tab[i])
			return (0);
		i++;
	}
	while (i < 16)
	{
		if (right_left(board, i - 12) != tab[i])
			return (0);
		i++;
	}
	return (1);
}

int	ft_verification(int board[4][4], int tab[16])
{
	if (ft_verify_vertical(board, tab) && ft_verify_horizontal(board, tab))
		return (1);
	return (0);
}
