find . -type f -name "*.c" | xargs norminette -R CheckForbiddenSourceHeader
